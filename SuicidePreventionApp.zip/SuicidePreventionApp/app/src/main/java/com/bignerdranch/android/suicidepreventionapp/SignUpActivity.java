package com.bignerdranch.android.suicidepreventionapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SignUpActivity extends AppCompatActivity {
    private static final String TAG = "SignUpActivity";
    private EditText firstName, lastName, email, password, confirmPassword
            , phoneNumber, counselorId,birthDate,
            gender, school, schoolId, graduationYear;
    private Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //method to link components
        linkComponents();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                performRegistration();

                Intent intent = new Intent(SignUpActivity.this, LogInActivity.class);
                startActivity(intent);

            }
        });

    }

    private void linkComponents(){
        firstName = (EditText)findViewById(R.id.first_name);
        lastName = (EditText)findViewById(R.id.last_name);
        email = (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.password);
        confirmPassword = (EditText)findViewById(R.id.confirm_password);
        birthDate = (EditText)findViewById(R.id.birth_date);
        phoneNumber = (EditText)findViewById(R.id.phone_number);
        gender = (EditText)findViewById(R.id.gender);
        school = (EditText)findViewById(R.id.school);
        schoolId = (EditText)findViewById(R.id.school_id);
        counselorId = (EditText)findViewById(R.id.counselor_id);
        graduationYear = (EditText)findViewById(R.id.graduation_year);
        register = (Button)findViewById(R.id.register_button);
    }

    private void performRegistration()
    {
        String user_first_name = firstName.getText().toString();
        String user_last_name = lastName.getText().toString();
        String user_email = email.getText().toString();
        String user_password = password.getText().toString();
        String user_gender = gender.getText().toString();
        String user_school = school.getText().toString();
        String user_school_id = schoolId.getText().toString();
        String user_graduation_year = graduationYear.getText().toString();
        String user_birth_date = birthDate.getText().toString();
        String user_phone_number = phoneNumber.getText().toString();
        String user_counselor_id = counselorId.getText().toString();
        Api api = RetrofitClient.getRetrofit().create(Api.class);
        Call<User> call = api.register(user_first_name + " " + user_last_name, user_email,user_password
                ,user_gender,user_school,user_school_id,user_graduation_year
                ,user_birth_date,user_phone_number,user_counselor_id);

        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                Toast.makeText(SignUpActivity.this, "You have been registered.", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Toast.makeText(SignUpActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });



    }
}













