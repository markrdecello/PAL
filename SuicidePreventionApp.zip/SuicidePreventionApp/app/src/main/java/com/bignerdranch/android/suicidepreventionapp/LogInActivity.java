package com.bignerdranch.android.suicidepreventionapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LogInActivity extends AppCompatActivity {

    private EditText email;
    private EditText password;
    private Button signInButton;
    private Button signUpButton;

    // http://pal.njcuacm.org/api/profile/10

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        //Linking
        email = (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.password);
        signInButton = (Button)findViewById(R.id.sign_in_button);
        signUpButton = (Button)findViewById(R.id.sign_up_button);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    authenticate();
                }
            }
        });

       signUpButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(LogInActivity.this, SignUpActivity.class);
               startActivity(intent);
           }
       });
    }



    private Boolean validate(){
        Boolean result = false;

        String userEmail = email.getText().toString();
        String userPassword = password.getText().toString();
        if (userEmail.isEmpty() && userPassword.isEmpty()){
            Toast.makeText(this, "Please enter email and password.", Toast.LENGTH_SHORT).show();
        }
        else {
            result = true;
        }

        return  result;

    }

    private void authenticate(){

        String user_email = email.getText().toString();
        String user_password = password.getText().toString();

        if (user_email.equals("danicarva@gmail.com") && user_password.equals("dani")){
            Intent mIntent = new Intent(LogInActivity.this, ProfileFragmentActivity.class);
            startActivity(mIntent);
        }

    }


}





















