package com.bignerdranch.android.suicidepreventionapp;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Api {

    @GET("profile/1")
    Call<User> getUser();


    @FormUrlEncoded
    @POST("register")
    Call<User> register(@Field("name") String name,
                        @Field("email") String email,
                        @Field("birthday") String birthday,
                        @Field("password") String password,
                        @Field("school") String school,
                        @Field("school_id") String school_id,
                        @Field("grad_year") String graduation_year,
                        @Field("gender") String gender,
                        @Field("phone_number") String phone_number,
                        @Field("counselor_id") String counselor_id
    );

    @POST("login")
    Call<User> userLogin(@Field("email") String email, @Field("password") String password, Callback<User> response);



}

